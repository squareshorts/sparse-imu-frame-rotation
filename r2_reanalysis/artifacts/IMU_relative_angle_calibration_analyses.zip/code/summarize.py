#!/usr/bin/env python3
"""Participant-level paired inference for matched relative angle and disjoint recalibration."""
from pathlib import Path
import numpy as np, pandas as pd, json
ROOT=Path('/mnt/data/imu_measurement_directed'); OUT=ROOT/'results'; NBOOT=5000
CAL_METHODS=['template_registration','gait_functional_calibration']

def ci(arr,seed):
    a=np.asarray(arr,float)
    assert len(a)>=3 and np.isfinite(a).all()
    rng=np.random.default_rng(seed)
    draws=rng.integers(0,len(a),(NBOOT,len(a)))
    boots=a[draws].mean(axis=1)
    return float(a.mean()),float(np.quantile(boots,.025)),float(np.quantile(boots,.975))

def paired(left,right,key=['cohort','target','subject']):
    a=left[key+['rmse_deg']].rename(columns={'rmse_deg':'left'})
    b=right[key+['rmse_deg']].rename(columns={'rmse_deg':'right'})
    m=a.merge(b,on=key,validate='one_to_one')
    if len(m)!=len(a) or len(m)!=len(b):raise AssertionError('Unpaired participants')
    return m['left'].to_numpy()-m['right'].to_numpy(),len(m)

rel=pd.concat([pd.read_csv(OUT/f'relative_participants_{co}_fold{fold}.csv') for co in ['virtual','physical'] for fold in range(1,6)],ignore_index=True)
rcyc=pd.concat([pd.read_csv(OUT/f'relative_cycles_{co}_fold{fold}.csv') for co in ['virtual','physical'] for fold in range(1,6)],ignore_index=True)
cal=pd.concat([pd.read_csv(OUT/f'calibration_participants_{co}_fold{fold}.csv') for co in ['virtual','physical'] for fold in range(1,6)],ignore_index=True)
ccyc=pd.concat([pd.read_csv(OUT/f'calibration_cycles_{co}_fold{fold}.csv') for co in ['virtual','physical'] for fold in range(1,6)],ignore_index=True)
assert len(rel.groupby(['cohort','subject','condition','axis','sign','target']))==len(rel)
assert all(len(rel[(rel.cohort==co)&(rel.condition=='zero')].subject.unique())==n for co,n in [('virtual',138),('physical',19)])

# Cross-check original deterministic y-axis 7.5° (both opposed) on the exact same subjects.
orig=pd.read_csv('/mnt/data/imu_measurement_deepen/results/axis_stress/all_axis_participants.csv')
checks=[]
for co in ['virtual','physical']:
    x=rel[(rel.cohort==co)&(rel.condition=='opposed_7p5')].copy()
    y=orig[(orig.cohort==co)&(orig.sensor_configuration=='both_opposed')].copy()
    x=x[['cohort','subject','target','axis','sign','rmse_deg']]
    y['sign']=y['sign'].str.replace('.5','',regex=False) if False else y['sign'].str[0].map({'+':1,'-':-1})
    y=y[['cohort','subject','target','axis','sign','participant_rmse_deg']]
    m=x.merge(y,on=['cohort','subject','target','axis','sign'],validate='one_to_one')
    assert len(m)==len(x)==len(y)
    md=float(np.max(np.abs(m.rmse_deg-m.participant_rmse_deg)))
    assert md<0.00001,(co,md)
    checks.append(dict(cohort=co,records=len(m),max_reproduction_abs_deg=md))

# Meaningful pairwise comparisons at identical 15° relative-perturbation magnitude.
# Average plus/minus per participant before bootstrapping to avoid pseudo-replication.
relb=(rel[rel.condition.isin(['opposed_7p5','first_15','second_15','first_7p5','second_7p5','both_same_7p5'])]
    .groupby(['cohort','condition','axis','target','subject'],as_index=False)
    .agg(rmse_deg=('rmse_deg','mean'), prediction_shift_rms_deg=('prediction_shift_rms_deg','mean'),
         error_fraction_gt4p5=('fraction_error_over4p5','mean')))

rr=[]
for i,(key,rows) in enumerate(relb.groupby(['cohort','condition','axis','target'],sort=True)):
    co,cond,axis,tgt=key
    rm=ci(rows.rmse_deg,100+i)
    rr.append(dict(cohort=co,condition=cond,axis=axis,target=tgt,n_subjects=len(rows),
        mean_participant_rmse_deg=rm[0],ci95_low_deg=rm[1],ci95_high_deg=rm[2],
        mean_participant_prediction_shift_deg=float(rows.prediction_shift_rms_deg.mean()),
        mean_fraction_cycles_abs_error_gt4p5=float(rows.error_fraction_gt4p5.mean())))
rs=pd.DataFrame(rr);rs.to_csv(OUT/'matched_relative_summary.csv',index=False)

contrasts=[];seed=1200
for co in ['virtual','physical']:
  for tgt in sorted(relb.target.unique()):
    q=relb[(relb.cohort==co)&(relb.target==tgt)]
    for cond in ['opposed_7p5','first_15','second_15']:
      yy=q[(q.condition==cond)&(q.axis=='y')]
      xx=q[(q.condition==cond)&(q.axis=='x')]
      zz=q[(q.condition==cond)&(q.axis=='z')]
      other=xx[['cohort','target','subject','rmse_deg']].merge(zz[['cohort','target','subject','rmse_deg']],on=['cohort','target','subject'])
      other['rmse_deg']=(other.rmse_deg_x+other.rmse_deg_y)/2
      diff,n=paired(yy,other[['cohort','target','subject','rmse_deg']])
      v=ci(diff,seed);seed+=1
      contrasts.append(dict(cohort=co,target=tgt,contrast='y-minus-mean-xz',condition=cond,n_subjects=n,mean_difference_deg=v[0],ci95_low_deg=v[1],ci95_high_deg=v[2]))
    for comp in ['first_15','second_15']:
      a=q[(q.condition=='opposed_7p5')&(q.axis=='y')]
      b=q[(q.condition==comp)&(q.axis=='y')]
      diff,n=paired(a,b)
      v=ci(diff,seed);seed+=1
      contrasts.append(dict(cohort=co,target=tgt,contrast='opposed-minus-'+comp,condition='local_y_relative15',n_subjects=n,
           mean_difference_deg=v[0],ci95_low_deg=v[1],ci95_high_deg=v[2]))
cn=pd.DataFrame(contrasts);cn.to_csv(OUT/'matched_relative_paired_contrasts.csv',index=False)

# Bootstrap individual signed conditions and worst of ALL 15°-relative cases
subsets=rel[(rel.condition.isin(['opposed_7p5','first_15','second_15']))].copy()
maxdata=[]
for co in ['virtual','physical']:
    q=subsets[subsets.cohort==co]
    matrix=q.pivot_table(index='subject',columns=['condition','axis','sign','target'],values='rmse_deg')
    assert matrix.shape==(138 if co=='virtual' else 19,3*3*2*4)
    a=matrix.to_numpy();rng=np.random.default_rng(22661)
    samples=np.empty(NBOOT)
    for st in range(0,NBOOT,128):
        en=min(st+128,NBOOT)
        b=a[rng.integers(0,len(a),(en-st,len(a)))].mean(axis=1).max(axis=1)
        samples[st:en]=b
    vals=matrix.mean().sort_values(ascending=False)
    maxdata.append(dict(cohort=co,max_case='|'.join(map(str,vals.index[0])),max_mean_rmse_deg=float(vals.iloc[0]),
        simultaneous_bootstrap_ci95_low=float(np.quantile(samples,.025)),simultaneous_bootstrap_ci95_high=float(np.quantile(samples,.975))))
mx=pd.DataFrame(maxdata);mx.to_csv(OUT/'matched_relative_joint_max.csv',index=False)

# Calibrated results with exact identical evaluation participants/records within cohort.
# Combine signs to participant means. Keep calibration state and k explicit.
cb=(cal[cal.condition.isin(['zero','opposed_7p5'])].groupby(
    ['cohort','method','calibration_state','calibration_k','condition','target','subject'],as_index=False)
    .agg(rmse_deg=('rmse_deg','mean'),q95_abs_error_deg=('q95_abs_error_deg','mean'),fraction_error_over4p5=('fraction_error_over4p5','mean')))
cal_sum=[]
for i,(key,rows) in enumerate(cb.groupby(['cohort','method','calibration_state','calibration_k','condition','target'],sort=True)):
    co,method,state,k,cond,tgt=key
    v=ci(rows.rmse_deg,30000+i)
    cal_sum.append(dict(cohort=co,method=method,calibration_state=state,calibration_size_k=k,condition=cond,target=tgt,
        n_subjects=len(rows),mean_participant_rmse_deg=v[0],ci95_low_deg=v[1],ci95_high_deg=v[2],
        mean_participant_q95_abs_error_deg=float(rows.q95_abs_error_deg.mean()),
        mean_fraction_cycles_abs_error_gt4p5=float(rows.fraction_error_over4p5.mean())))
cs=pd.DataFrame(cal_sum);cs.to_csv(OUT/'disjoint_calibration_summary.csv',index=False)
cal_con=[];seed=90000
for co in ['virtual','physical']:
  k=3 if co=='virtual' else 5
  for tgt in sorted(cal.target.unique()):
    b=cb[(cb.cohort==co)&(cb.target==tgt)]
    augzero=b[(b.method=='augmentation')&(b.condition=='zero')]
    augrot=b[(b.method=='augmentation')&(b.condition=='opposed_7p5')]
    for method in CAL_METHODS:
      normzero=b[(b.method==method)&(b.calibration_k==k)&(b.condition=='zero')&(b.calibration_state=='reestimated')]
      normfresh=b[(b.method==method)&(b.calibration_k==k)&(b.condition=='opposed_7p5')&(b.calibration_state=='reestimated')]
      normstale=b[(b.method==method)&(b.calibration_k==k)&(b.condition=='opposed_7p5')&(b.calibration_state=='retained')]
      tests=[('clean_calibration_cost_vs_augmentation',normzero,augzero),
            ('adverse_error_reduction_fresh_vs_augmentation',normfresh,augrot),
            ('adverse_error_fresh_vs_stale',normfresh,normstale),
            ('fresh_rotation_invariance_vs_own_clean',normfresh,normzero)]
      for label,left,right in tests:
        diff,n=paired(left,right)
        m=ci(diff,seed);seed+=1
        cal_con.append(dict(cohort=co,target=tgt,method=method,calibration_k=k,contrast=label,n_subjects=n,
             mean_paired_difference_deg=m[0],ci95_low_deg=m[1],ci95_high_deg=m[2]))
cal_c=pd.DataFrame(cal_con);cal_c.to_csv(OUT/'disjoint_calibration_paired_contrasts.csv',index=False)
# Cycle-wise 95th absolute error across all participants for main evaluation (not independent samples).
cyc=ccyc[(ccyc.condition.isin(['zero','opposed_7p5']))].copy()
cyc=cyc[(((cyc.cohort=='virtual')&(cyc.calibration_k==3))|((cyc.cohort=='physical')&(cyc.calibration_k==5))|(cyc.method=='augmentation'))]
tail=(cyc.groupby(['cohort','method','calibration_state','calibration_k','condition','target'],sort=True)
    .agg(n_scoring_rows=('abs_error_deg','count'),q95_cycle_abs_error_deg=('abs_error_deg',lambda x:float(np.percentile(x,95))),
         fraction_cycles_abs_error_gt4p5=('abs_error_deg',lambda x:float(np.mean(x>4.5))),
         maximum_abs_error_deg=('abs_error_deg','max')).reset_index())
tail.to_csv(OUT/'disjoint_calibration_tail_errors.csv',index=False)

# Show exact near-equality of k calibrated re-estimated predictions under rotation vs clean.
inv=cal_c[cal_c.contrast=='fresh_rotation_invariance_vs_own_clean']
print('REPRO CHECKS',checks)
print('MAX',mx.to_string(index=False))
print('Y VS XZ VIRTUAL')
print(cn[(cn.cohort=='virtual')&(cn.contrast=='y-minus-mean-xz')].to_string(index=False))
print('OPPOSED VS SINGLE Y VIRTUAL')
print(cn[(cn.cohort=='virtual')&(cn.contrast.str.startswith('opposed'))].to_string(index=False))
print('CALIBRATION CONTRASTS')
print(cal_c.to_string(index=False))
print('MAX ABS INVARIANCE',inv.mean_paired_difference_deg.abs().max())
# Hard tests
assert inv.mean_paired_difference_deg.abs().max()<0.0001
assert all(n == cb[cb.cohort==co].subject.nunique() for co,n in [('virtual',113),('physical',19)])
(OUT/'analysis_manifest.json').write_text(json.dumps({'status':'completed','resampling_unit':'participant','bootstrap_resamples':NBOOT,
    'matched_relative_angles_deg':15,'per_sensor_opposing_angle_deg':7.5,'single_sensor_angle_deg':15,
    'calibration_method':'frame estimated on heldout participants using disjoint calibration cycles, optionally retained from pre-rotation frame',
    'calibration_sizes_virtual':[1,3],'calibration_sizes_physical':[1,3,5],
    'original_directional_results_reproduced':checks,'source_virtual_cycles':747,'source_virtual_subjects':138,
    'source_physical_windows':248,'source_physical_subjects':19,
    'limitation':'post hoc direction stress, cohort-specific frame definitions; artificial rotations do not reproduce physical remounting'},indent=2))
print('DONE SUMMARY')
