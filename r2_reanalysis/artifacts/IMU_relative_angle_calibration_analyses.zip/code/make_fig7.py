from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
P=Path('/mnt/data/imu_measurement_directed/results');O=Path('/mnt/data/imu_measurement_directed/latex')
r=pd.read_csv(P/'matched_relative_summary.csv');c=pd.read_csv(P/'disjoint_calibration_paired_contrasts.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
blue='#284b63';orange='#b75b31';green='#26766a';grey='#69727d'
fig,(ax,bx)=plt.subplots(1,2,figsize=(12,4.55),gridspec_kw={'width_ratios':[1.03,1.13]})
# 15 deg matched rotation difference, knee stance endpoint.
lineitems=[('opposed_7p5','Two sensors, opposing 7.5°',blue,'o'),('first_15','First sensor, 15°',orange,'s'),('second_15','Second sensor, 15°',green,'D')]
for cond,label,col,mark in lineitems:
    q=r[(r.cohort=='virtual')&(r.condition==cond)&(r.target=='knee_stance_flex_deg')].set_index('axis').loc[['x','y','z']]
    y=q.mean_participant_rmse_deg.to_numpy();lo=q.ci95_low_deg.to_numpy();hi=q.ci95_high_deg.to_numpy()
    ax.errorbar(range(3),y,yerr=[y-lo,hi-y],label=label,color=col,marker=mark,markersize=5.5,linewidth=1.8,capsize=3)
ax.axhline(4.5,color=grey,linewidth=1,ls=(0,(4,3)))
ax.set_xticks([0,1,2],['Local x','Local y','Local z'])
ax.set_ylabel('Knee-stance RMSE (degrees)')
ax.set_ylim(2.2,8.0)
ax.set_title('a  Same 15° imposed relative rotation',loc='left',weight='bold',fontsize=10.2)
ax.legend(frameon=False,fontsize=7.5,loc='upper right',handlelength=2)
ax.grid(axis='y',alpha=.16)
# Paired normalized-vs-augmented contrasts: positive baseline penalty,
# negative under opposing y. Four endpoints.
order=[('ankle_dorsiflex_deg','Ankle dorsiflexion'),('ankle_plantarflex_deg','Ankle plantarflexion'),('knee_stance_flex_deg','Knee stance'),('knee_swing_flex_deg','Knee swing')]
cs=c[(c.cohort=='virtual')&(c.method=='template_registration')&(c.calibration_k==3)]
for i,(tgt,label) in enumerate(order):
    for off,contrast,col,mark in [(-.15,'clean_calibration_cost_vs_augmentation',orange,'o'),(.15,'adverse_error_reduction_fresh_vs_augmentation',green,'D')]:
        q=cs[(cs.target==tgt)&(cs.contrast==contrast)].iloc[0]
        x=q.mean_paired_difference_deg;lo=q.ci95_low_deg;hi=q.ci95_high_deg
        bx.errorbar(x,i+off,xerr=[[x-lo],[hi-x]],color=col,fmt=mark,markersize=5.8,capsize=3,lw=1.65)
bx.set_yticks(range(len(order)),[label for _,label in order])
bx.invert_yaxis();bx.axvline(0,color=grey,lw=1,ls=(0,(4,3)))
bx.set_xlabel('Registration minus augmented Ridge RMSE (degrees)')
bx.set_title('b  Accuracy cost and adverse-rotation gain',loc='left',weight='bold',fontsize=10.2)
bx.set_xlim(-2.55,1.6);bx.grid(axis='x',alpha=.16)
fig.legend(handles=[Line2D([0],[0],color=orange,marker='o',linestyle='None',label='Clean: registration cost'),Line2D([0],[0],color=green,marker='D',linestyle='None',label='Opposing local-y: post-rotation calibration')],loc='lower center',bbox_to_anchor=(.68,.025),ncol=1,frameon=False,fontsize=8.0)
fig.subplots_adjust(left=.07,right=.985,top=.86,bottom=.31,wspace=.36)
for suf in ('.pdf','.png'):
    fig.savefig(O/('fig7_relative_angle_and_calibration'+suf),dpi=210 if suf=='.png' else None,bbox_inches='tight')
plt.close(fig)
