#!/usr/bin/env python3
"""Matched-relative-angle and disjoint-calibration study of sensor-frame rotations.

Input: frozen virtual cohort and SHA-verified Camargo prepared cohort. All fits are
participant-disjoint. Exact model/seed/rotation functions from the frozen pipeline.
"""
from __future__ import annotations
import argparse,hashlib,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path('/mnt/data/imu_measurement_deepen')
CODE=ROOT/'repo'/'analysis_code'
sys.path.insert(0,str(CODE))
sys.path.insert(0,str(ROOT/'code'))
from src.confirmatory.data import load_study_data
from src.confirmatory.folds import load_outer_folds
from src.confirmatory.constants import PRIMARY_TASKS
from src.confirmatory.orientation import make_augmented_training_set,axis_angle_to_matrix,rotate_sensor_block
from src.confirmatory.features import engineered_features
from strengthening.run_rotation_matrix_v2 import WeightedRidge
from strengthening.run_orientation_baselines_fold import (build_training_templates,_phase_signature,_kabsch_row,functional_frame)
from calibration_common_set import common_subset
SEED=20260907
TASKS_V=[(n,PRIMARY_TASKS[n]['sensors'],PRIMARY_TASKS[n]['targets'],PRIMARY_TASKS[n]['target_names']) for n in ['knee_two','ankle_two']]
TASKS_P=[('knee_two',(1,2),(0,1),('knee_stance_flex_deg','knee_swing_flex_deg')),('ankle_two',(2,3),(2,3),('ankle_dorsiflex_deg','ankle_plantarflex_deg'))]
CAL_METHODS=['template_registration','gait_functional_calibration']


def cases():
    ret=[('zero','none',0,0,0.)]
    for axis in range(3):
        for sign in (1,-1):
            for group in ('opposed_7p5','first_15','second_15','both_same_7p5','first_7p5','second_7p5'):
                ret.append((group,'xyz'[axis],sign,axis,15. if '15' in group else 7.5))
    return ret

def matrix(axis,deg):
    return axis_angle_to_matrix(np.eye(3)[axis],np.deg2rad(deg))

def perturb(X, sensors, case):
    group,letter,sign,axis,angle=case
    if group=='zero':return X
    r=matrix(axis,sign*angle)
    rr=r.T
    out=X.copy()
    if group in ('first_15','first_7p5','both_same_7p5','opposed_7p5'):
        out[:,sensors[0]]=rotate_sensor_block(X[:,sensors[0]],r)
    if group in ('second_15','second_7p5','both_same_7p5'):
        out[:,sensors[1]]=rotate_sensor_block(X[:,sensors[1]],r)
    if group=='opposed_7p5':
        out[:,sensors[1]]=rotate_sensor_block(X[:,sensors[1]],rr)
    return out

def relative_deg(case):
    group,letter,sign,axis,angle=case
    return 0. if group in ('zero','both_same_7p5') else (15. if group in ('opposed_7p5','first_15','second_15') else 7.5)

def calibration_transforms(Xcal, Gcal, templates,sensors, method, ids):
    tr={}
    for sid in ids:
        ii=np.flatnonzero(Gcal==sid)
        assert len(ii)
        for sen in sensors:
            if method=='template_registration':
                a=_phase_signature(Xcal[ii,sen])
                R=_kabsch_row(a,templates[int(sen)])
            else:
                R=functional_frame(Xcal[ii,sen]).T
            tr[(int(sid),int(sen))]=R
    return tr

def apply_transforms(Xeval,Geval,sensors,matrices):
    result=Xeval.copy()
    for sid in np.unique(Geval):
        ii=np.flatnonzero(Geval==sid)
        for sen in sensors:
            M=matrices[(int(sid),int(sen))]
            a=Xeval[ii,sen]
            result[ii,sen,:,:3]=a[:,:,:3]@M
            result[ii,sen,:,3:]=a[:,:,3:]@M
    return result

def participant_rows(pred,y,base,G,task,names,case,cohort,fold,analysis,k=0,method='augmented_ridge',cal_state='not_applicable',global_eval_idx=None):
    ret=[]; full=[]
    for sid in np.unique(G):
        ix=np.flatnonzero(G==sid)
        for j,name in enumerate(names):
            err=(pred[ix,j]-y[ix,j]).astype(float);shift=(pred[ix,j]-base[ix,j]).astype(float)
            group,axis,sign,_,angle=case
            key=dict(cohort=cohort,fold=fold,analysis=analysis,method=method,calibration_state=cal_state,calibration_k=k,
                     condition=group,axis=axis,sign=sign,per_sensor_angle_deg=angle,relative_angle_deg=relative_deg(case),
                     task=task,target=name,subject=int(sid),n_eval=len(ix))
            ret.append(dict(**key,rmse_deg=float(np.sqrt(np.mean(err*err))),mae_deg=float(np.mean(np.abs(err))),
                            prediction_shift_rms_deg=float(np.sqrt(np.mean(shift*shift))),
                            fraction_error_over4p5=float(np.mean(np.abs(err)>4.5)),
                            q95_abs_error_deg=float(np.quantile(np.abs(err),.95))))
            # Cycle-level results for pooled upper-tail metrics, retaining common scoring indices.
            for jx,m in enumerate(ix):
                full.append(dict(**{p:key[p] for p in key if p not in ('n_eval',)},eval_record=int(m if global_eval_idx is None else global_eval_idx[m]),
                                 abs_error_deg=float(abs(err[jx])),abs_shift_deg=float(abs(shift[jx]))))
    return ret,full

def load(cohort):
    if cohort=='virtual':
        source=CODE/'data/processed/strict_parameters.npz'
        expected='f75bc8ca9c9cad0a6d4b853b7fd55d3637e5a485dbfdb9f27fa18405cdd2db9e'
        assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
        d=load_study_data(source)
        return d.X,d.T,d.subjects,d.durations,d.speeds,load_outer_folds(CODE/'protocol/outer_folds.csv',d.subjects),TASKS_V
    with np.load(ROOT/'physical'/'camargo_external.npz',allow_pickle=True) as d:
        return tuple(d[k] for k in ('X','T','subjects','durations','speeds','outer_fold'))+(TASKS_P,)

def run(cohort,fold,out):
    start=time.time()
    X,T,G,D,S,F,tasks=load(cohort)
    train=np.flatnonzero(F!=fold);test=np.flatnonzero(F==fold)
    assert not set(G[train])&set(G[test])
    Xte,Tte,Gte,Dte,Ste=X[test],T[test],G[test],D[test],S[test]
    cal_sizes=(1,3) if cohort=='virtual' else (1,3,5)
    calibs,evalidx,participant_eval_n=common_subset(Gte,cal_sizes)
    if cohort=='physical':
        with np.load(ROOT/'physical'/'camargo_external.npz',allow_pickle=True) as d:
            bad=np.flatnonzero((d['subject_names']=='AB25')&(d['source_window']==0))
        assert len(bad)==1
        evalidx=evalidx[test[evalidx]!=bad[0]]
    assert not set(np.concatenate(list(calibs[max(cal_sizes)].values())))&set(evalidx)
    print(cohort,'fold',fold,'training',len(train),'testing',len(test),'calibrated_eval',len(evalidx),'subjects',len(set(Gte[evalidx])),flush=True)
    mat_part=[];mat_cycle=[];cal_part=[];cal_cycle=[]
    for ti,(task,sensors,targets,names) in enumerate(tasks):
        seed=(SEED+fold*2000000+100*10000+ti if cohort=='virtual' else SEED+fold*100000+len(task)*1000+100)
        xt,yt,gt,dt,st=make_augmented_training_set(X[train],T[train][:,targets],G[train],D[train],S[train],sensors,10.,5,seed)
        ft=engineered_features(xt,sensors,dt,st)
        aug=WeightedRidge(100.).fit(ft,yt,np.full(len(ft),1./6.))
        base=aug.predict(engineered_features(Xte,sensors,Dte,Ste))
        templates=build_training_templates(X[train],G[train],sensors)
        normalize_models={}
        for method in CAL_METHODS:
            if method=='template_registration':
                # training transforms use each subject training-record signature, as original protocol.
                from strengthening.run_orientation_baselines_fold import template_register
                xtr=template_register(X[train],G[train],sensors,templates)
            else:
                from strengthening.run_orientation_baselines_fold import functional_register
                xtr=functional_register(X[train],G[train],sensors)
            ftr=engineered_features(xtr,sensors,D[train],S[train])
            normalize_models[method]=WeightedRidge(100.).fit(ftr,T[train][:,targets])
        # A: fixed matched relative angles, original test record set; all four endpoints.
        for case in cases():
            Xpert=perturb(Xte,sensors,case)
            pred=aug.predict(engineered_features(Xpert,sensors,Dte,Ste))
            pp,cc=participant_rows(pred,Tte[:,targets],base,Gte,task,names,case,cohort,fold,'matched_relative_angle',global_eval_idx=test)
            mat_part.extend(pp);mat_cycle.extend(cc)
        # B: only adverse local-y configurations, plus matched 15-degree single-sensor comparators.
        ycases=[('zero','none',0,0,0.)]
        for sign in (1,-1):
            for cfg in ('opposed_7p5','first_15','second_15'):
                ycases.append((cfg,'y',sign,1,7.5 if cfg=='opposed_7p5' else 15.))
        calX=Xte; calG=Gte
        for case in ycases:
            Xpert=perturb(Xte,sensors,case)
            # Compare augmented Ridge on identical held-out scoring records.
            paug=aug.predict(engineered_features(Xpert[evalidx],sensors,Dte[evalidx],Ste[evalidx]))
            pp,cc=participant_rows(paug,Tte[evalidx][:,targets],base[evalidx],Gte[evalidx],task,names,case,cohort,fold,'disjoint_calibration',
                                    method='augmentation',global_eval_idx=test[evalidx])
            cal_part.extend(pp);cal_cycle.extend(cc)
            # Baseline for each normalization method must be constructed using the
            # same unperturbed calibration/evaluation split, separately for k.
            for method in CAL_METHODS:
                for k in cal_sizes:
                    cidx=np.concatenate(list(calibs[k].values()))
                    assert not set(cidx)&set(evalidx)
                    # The fresh frame is estimated AFTER the imposed remounting, on separate records.
                    fresh=calibration_transforms(Xpert[cidx],Gte[cidx],templates,sensors,method,np.unique(Gte[evalidx]))
                    stale=calibration_transforms(calX[cidx],calG[cidx],templates,sensors,method,np.unique(Gte[evalidx]))
                    for state,mats in (('reestimated',fresh),('retained',stale)):
                        xreg=apply_transforms(Xpert[evalidx],Gte[evalidx],sensors,mats)
                        pred=normalize_models[method].predict(engineered_features(xreg,sensors,Dte[evalidx],Ste[evalidx]))
                        # At zero rotation the fresh and retained transforms coincide.
                        pp,cc=participant_rows(pred,Tte[evalidx][:,targets],np.zeros_like(pred),Gte[evalidx],task,names,case,cohort,fold,'disjoint_calibration',
                                                k=k,method=method,cal_state=state,global_eval_idx=test[evalidx])
                        cal_part.extend(pp);cal_cycle.extend(cc)
        print(cohort,'fold',fold,'task',task,'elapsed',round(time.time()-start,1),flush=True)
    out.mkdir(parents=True,exist_ok=True)
    for name,rows in [('relative_participants',mat_part),('relative_cycles',mat_cycle),('calibration_participants',cal_part),('calibration_cycles',cal_cycle)]:
        pd.DataFrame(rows).to_csv(out/f'{name}_{cohort}_fold{fold}.csv',index=False)
    print('DONE',cohort,fold,'elapsed',round(time.time()-start,1),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('cohort',choices=['virtual','physical']);ap.add_argument('fold',type=int);ap.add_argument('--out',type=Path,default=Path('/mnt/data/imu_measurement_directed/results'))
    args=ap.parse_args();assert 1<=args.fold<=5
    run(args.cohort,args.fold,args.out)
