# Reproduce the extended IMU analyses

These are the exact successful scripts and corresponding outputs, separated from the manuscript. The raw Camargo HDF5 and complete public virtual-source Git repository are not redistributed here. The prepared physical NPZ is supplied to avoid repeating upstream transformation.

Prerequisites: Python 3.11+ with numpy, pandas, scipy, scikit-learn, h5py, and matplotlib. The numerical runs used numpy 2.3.5, pandas 2.2.3, scipy 1.17.0, scikit-learn 1.8.0, h5py 3.15.1, matplotlib 3.10.8.

Place the frozen virtual repository under the extracted archive root as `repo/`:

    git clone https://github.com/squareshorts/sparse-imu-frame-rotation.git repo
    git -C repo checkout 3609b490194670bf69f82c5a166ffdfa5aadb3f3

`physical/camargo_external.npz` is already supplied. To independently regenerate from the original Camargo HDF5, run:

    python prepare_camargo_external.py --input /PATH/Camargo_levelground.h5 --outdir physical

Then from the archive root:

    python stage1_nested_physical.py
    python stage2_virtual_fold.py 1
    python stage2_virtual_fold.py 2
    python stage2_virtual_fold.py 3
    python stage2_virtual_fold.py 4
    python stage2_virtual_fold.py 5
    python stage2_virtual_summarize.py
    python stage3_axis_fold.py virtual 1
    python stage3_axis_fold.py virtual 2
    python stage3_axis_fold.py virtual 3
    python stage3_axis_fold.py virtual 4
    python stage3_axis_fold.py virtual 5
    python stage3_axis_fold.py physical 1
    python stage3_axis_fold.py physical 2
    python stage3_axis_fold.py physical 3
    python stage3_axis_fold.py physical 4
    python stage3_axis_fold.py physical 5
    python stage3_axis_summarize.py
    python stage4_units.py
    python stage5_crosscohort_inference.py
    python make_scientific_figure.py

For inference, participant pooling and sampling seeds are explicitly defined in the scripts. Results were numerically compared with frozen source means as part of each stage. The `results/` tree contains the fully executed results, including participant-level error components, every directional condition, the joint bootstrap and model-selection summaries. Successful-run log files are under `logs/`. No aborted intermediate experiment script is included.
