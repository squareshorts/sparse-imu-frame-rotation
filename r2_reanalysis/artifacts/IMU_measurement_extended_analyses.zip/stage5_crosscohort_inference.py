"""Between-cohort uncertainty on rotation prediction sensitivity and bootstrapped directional stress maximum."""
from __future__ import annotations
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'/'inference';OUT.mkdir(parents=True,exist_ok=True)
V=pd.read_csv(ROOT/'results'/'virtual_decomp'/'participant_prediction_decomposition.csv')
P=pd.read_csv(ROOT/'results'/'physical_nested'/'participant_nested_and_decomp.csv')
P=P[P.variant=='fixed_source']
rows=[];B=5000
for i,(keys,v) in enumerate(V.groupby(['train_cap_deg','test_angle_deg','target'],sort=True)):
 cap,ang,tgt=keys
 if ang==0:continue
 p=P[(P.train_cap_deg==cap)&(P.test_angle_deg==ang)&(P.target==tgt)]
 assert (len(v),len(p))==(138,19),(keys,len(v),len(p))
 vs=np.sqrt(v.delta_pred_mse_deg2.to_numpy());ps=np.sqrt(p.delta_pred_mse_deg2.to_numpy())
 rng=np.random.default_rng(24142+i)
 bvi=vs[rng.integers(0,len(vs),(B,len(vs)))].mean(1)
 bpi=ps[rng.integers(0,len(ps),(B,len(ps)))].mean(1)
 diff=bvi-bpi;rat=bvi/bpi
 rows.append(dict(train_cap_deg=cap,test_angle_deg=ang,target=tgt,
  n_virtual=len(vs),n_physical=len(ps),virtual_prediction_shift_rms_mean_deg=float(vs.mean()),
  physical_prediction_shift_rms_mean_deg=float(ps.mean()),
  virtual_minus_physical_pred_shift_mean_deg=float(vs.mean()-ps.mean()),
  difference_ci95_low_deg=float(np.quantile(diff,.025)),difference_ci95_high_deg=float(np.quantile(diff,.975)),
  shift_ratio_virtual_over_physical=float(vs.mean()/ps.mean()),
  shift_ratio_ci95_low=float(np.quantile(rat,.025)),shift_ratio_ci95_high=float(np.quantile(rat,.975)),
  virtual_baseline_mse_deg2=float(v.baseline_mse_deg2.mean()),physical_baseline_mse_deg2=float(p.baseline_mse_deg2.mean()),
  virtual_rotation_delta_mse_deg2=float(v.delta_pred_mse_deg2.mean()),physical_rotation_delta_mse_deg2=float(p.delta_pred_mse_deg2.mean()),
  virtual_cross_term_mse_deg2=float(v.cross_mse_deg2.mean()),physical_cross_term_mse_deg2=float(p.cross_mse_deg2.mean())))
res=pd.DataFrame(rows);res.to_csv(OUT/'prediction_shift_cohort_contrasts.csv',index=False)
# Joint participant bootstrap of the maximum of 96 deterministic directional conditions, accounting for selection of the worst case.
Q=pd.read_csv(ROOT/'results'/'axis_stress'/'all_axis_participants.csv')
Q=Q[(Q.cohort=='virtual')&(Q.condition=='rotated')].copy()
Q['case']=Q['target']+'__'+Q['axis']+'__'+Q['sign']+'__'+Q['sensor_configuration']
M=Q.pivot(index='subject',columns='case',values='participant_rmse_deg').sort_index()
assert M.shape==(138,96),M.shape
m=M.to_numpy();observed=float(m.mean(axis=0).max());obs_col=M.columns[int(m.mean(axis=0).argmax())]
rng=np.random.default_rng(26404)
maxmean=[]
for _ in range(10):
 ix=rng.integers(0,len(m),(500,len(m)))
 maxmean.extend(m[ix].mean(axis=1).max(axis=1))
lo,hi=np.quantile(maxmean,[.025,.975])
axisinfo=pd.DataFrame([dict(cohort='virtual',test_angle_deg=7.5,train_cap_deg=10.,
 n_participants=138,axis_endpoint_cases=96,observed_max_mean_participant_rmse_deg=observed,
 boot_max_mean_ci95_low_deg=float(lo),boot_max_mean_ci95_high_deg=float(hi),
 observed_worst_case=obs_col,n_bootstrap=5000)])
axisinfo.to_csv(OUT/'joint_bootstrap_worst_axis_mean.csv',index=False)
print('JOINT AXIS WORST\n',axisinfo.to_string(index=False))
print('COHORT CAP0 AT 10\n',res[(res.train_cap_deg==0)&(res.test_angle_deg==10)].to_string(index=False))
print('COHORT CAP10 AT 10\n',res[(res.train_cap_deg==10)&(res.test_angle_deg==10)][['target','virtual_minus_physical_pred_shift_mean_deg','difference_ci95_low_deg','difference_ci95_high_deg','shift_ratio_virtual_over_physical']].to_string(index=False))
