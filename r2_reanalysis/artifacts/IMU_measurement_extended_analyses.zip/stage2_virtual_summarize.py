from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'/'virtual_decomp'
part=pd.concat([pd.read_csv(OUT/f'participant_fold{x}.csv') for x in range(1,6)],ignore_index=True)
assert len(part)==4968,(len(part),part.groupby(['train_cap_deg','test_angle_deg','target']).size().head())
assert part.groupby(['train_cap_deg','test_angle_deg','target']).subject.nunique().eq(138).all()
part.to_csv(OUT/'participant_prediction_decomposition.csv',index=False)
def boot_ci(a,seed,B=5000):
 a=np.asarray(a,float);rng=np.random.default_rng(seed);b=np.mean(a[rng.integers(0,len(a),(B,len(a)))],axis=1)
 return [float(a.mean()),*map(float,np.quantile(b,[.025,.975]))]
summary=[]
for i,(keys,q) in enumerate(part.groupby(['train_cap_deg','test_angle_deg','target'],sort=True)):
 cap,ang,tgt=keys;mm=boot_ci(q.rmse_deg,1000+i)
 summary.append(dict(train_cap_deg=cap,test_angle_deg=ang,target=tgt,n_subjects=len(q),
  mean_rmse_deg=mm[0],ci95_low_deg=mm[1],ci95_high_deg=mm[2],
  mean_clean_rmse_deg=float(np.sqrt(q.baseline_mse_deg2).mean()),
  mean_prediction_shift_rms_deg=float(np.sqrt(q.delta_pred_mse_deg2).mean()),
  mean_baseline_mse_deg2=q.baseline_mse_deg2.mean(),mean_delta_pred_mse_deg2=q.delta_pred_mse_deg2.mean(),
  mean_cross_mse_deg2=q.cross_mse_deg2.mean(),mean_rotated_mse_deg2=q.rotated_mse_deg2.mean()))
sumdf=pd.DataFrame(summary);sumdf.to_csv(OUT/'decomposition_summary.csv',index=False)
ref=pd.read_csv(ROOT/'repo'/'reproduction_evidence/virtual/rotation_matrix_v2/matrix_summary.csv')
base=ref.rename(columns={'train_augmentation_max_deg':'train_cap_deg','test_rotation_deg':'test_angle_deg','mean_participant_rmse_deg':'published_mean_deg'})
check=sumdf.merge(base,on=['train_cap_deg','test_angle_deg','target'],validate='one_to_one')
check['abs_diff_mean_deg']=(check.mean_rmse_deg-check.published_mean_deg).abs()
check[['train_cap_deg','test_angle_deg','target','mean_rmse_deg','published_mean_deg','abs_diff_mean_deg']].to_csv(OUT/'reference_mean_checks.csv',index=False)
maxdiff=float(check.abs_diff_mean_deg.max());print('MAX source mean discrepancy',maxdiff,flush=True)
assert maxdiff<5e-4,maxdiff
print('UN-AUGMENTED VIRTUAL 10 DEG\n',sumdf[(sumdf.train_cap_deg==0)&(sumdf.test_angle_deg==10)].to_string(index=False),flush=True)
