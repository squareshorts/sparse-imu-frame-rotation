"""Exact virtual protocol plus paired prediction-shift/MSE decomposition, separate from physical nested tuning."""
from __future__ import annotations
import sys,time
from pathlib import Path
from collections import defaultdict
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;CODE=ROOT/'repo'/'analysis_code';sys.path.insert(0,str(CODE))
from src.confirmatory.data import load_study_data
from src.confirmatory.folds import load_outer_folds
from src.confirmatory.constants import PRIMARY_TASKS
from src.confirmatory.orientation import make_augmented_training_set,perturb_by_subject
from src.confirmatory.features import engineered_features
from strengthening.run_rotation_matrix_v2 import WeightedRidge
D=load_study_data(CODE/'data/processed/strict_parameters.npz')
F=load_outer_folds(CODE/'protocol/outer_folds.csv',D.subjects)
OUT=ROOT/'results'/'virtual_decomp';OUT.mkdir(parents=True,exist_ok=True)
CAPS=[0.,7.5,10.];ANGLES=[0.,7.5,10.];SEED=20260907;MC=50;COPIES=5
TASKS=['knee_two','ankle_two']

def boot_ci(a,seed=1,B=5000):
 a=np.asarray(a,float);rng=np.random.default_rng(seed);boot=np.mean(a[rng.integers(0,len(a),(B,len(a)))],axis=1)
 return [float(a.mean()),*map(float,np.quantile(boot,[.025,.975]))]

start=time.time();acc=defaultdict(lambda:[0.,0.,0.,0.,0]);errors=None;predshifts=None
for fold in [int(sys.argv[1])]:
 tr=np.flatnonzero(F!=fold);te=np.flatnonzero(F==fold);g=D.subjects[te];uniq=np.unique(g)
 assert not(set(D.subjects[tr])&set(D.subjects[te]))
 smap={s:np.flatnonzero(g==s) for s in uniq}
 for ti,taskname in enumerate(TASKS):
  task=PRIMARY_TASKS[taskname];targets=task['targets'];sensors=task['sensors'];endpoints=task['target_names'];y=D.T[te][:,targets]
  models={};p0={};F0=engineered_features(D.X[te],sensors,D.durations[te],D.speeds[te])
  for cap in CAPS:
   copies=COPIES if cap>0 else 0
   seed=SEED+fold*2000000+int(round(cap*10))*10000+ti
   Xa,Ya,Ga,Da,Sa=make_augmented_training_set(D.X[tr],D.T[tr][:,targets],D.subjects[tr],D.durations[tr],D.speeds[tr],sensors,cap,copies,seed)
   Ftr=engineered_features(Xa,sensors,Da,Sa)
   weights=np.full(len(Ftr),1./(copies+1)) if copies else np.ones(len(Ftr))
   models[cap]=WeightedRidge(10. if cap==0 else 100.).fit(Ftr,Ya,weights)
   p0[cap]=models[cap].predict(F0)
  for ang in ANGLES:
   for rep in range(1 if ang==0 else MC):
    if ang==0:Xe=D.X[te]
    else:
     ps=SEED+fold*3000000+ti*100000+int(round(ang*10))*100+rep
     Xe,_=perturb_by_subject(D.X[te],g,sensors,ang,ps,exact_angle=True)
    Fe=engineered_features(Xe,sensors,D.durations[te],D.speeds[te])
    for cap in CAPS:
     pp=models[cap].predict(Fe);e=pp-y;e0=p0[cap]-y;dp=pp-p0[cap]
     for sid,ix in smap.items():
      for j,tgt in enumerate(endpoints):
       k=(cap,ang,taskname,tgt,int(sid));a=acc[k]
       a[0]+=float(np.sum(e[ix,j]**2));a[1]+=float(np.sum(e0[ix,j]**2));a[2]+=float(np.sum(dp[ix,j]**2));a[3]+=float(np.sum(2*e0[ix,j]*dp[ix,j]));a[4]+=len(ix)
       
   print('fold',fold,taskname,'ang',ang,'seconds',round(time.time()-start,1),flush=True)
rows=[]
for (cap,ang,task,tgt,sid),(se,base,shift,cross,n) in acc.items():
 assert abs(se-base-shift-cross)<max(1e-4,1e-5*se)
 k=(cap,ang,task,tgt,sid)
 rows.append(dict(train_cap_deg=cap,test_angle_deg=ang,task=task,target=tgt,subject=sid,pooled_error_count=n,
  rmse_deg=np.sqrt(se/n),baseline_mse_deg2=base/n,delta_pred_mse_deg2=shift/n,cross_mse_deg2=cross/n,
  rotated_mse_deg2=se/n))
part=pd.DataFrame(rows);part.to_csv(OUT/f'participant_fold{fold}.csv',index=False)
print('FOLD_DONE',fold,'n_rows',len(part),'elapsed',round(time.time()-start,1),flush=True)
