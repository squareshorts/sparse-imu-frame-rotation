"""Signed local-coordinate principal-axis perturbations at exactly 7.5 degrees.

Each distinct case is a deliberate directional stress condition, not a random-axis validation draw.
Rotation applied once and held fixed across cycles of each participant.
"""
from __future__ import annotations
import sys,time
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;CODE=ROOT/'repo'/'analysis_code';sys.path.insert(0,str(CODE))
from src.confirmatory.data import load_study_data
from src.confirmatory.folds import load_outer_folds
from src.confirmatory.constants import PRIMARY_TASKS
from src.confirmatory.orientation import make_augmented_training_set,axis_angle_to_matrix,rotate_sensor_block
from src.confirmatory.features import engineered_features
from strengthening.run_rotation_matrix_v2 import WeightedRidge
cohort=sys.argv[1];fold=int(sys.argv[2]); assert cohort in ('virtual','physical') and 1<=fold<=5
out=ROOT/'results'/'axis_stress';out.mkdir(parents=True,exist_ok=True)
SEED=20260907;CAP=10.;COPIES=5;ANG=7.5
if cohort=='virtual':
 d=load_study_data(CODE/'data/processed/strict_parameters.npz')
 X,T,G,DUR,SPEED=d.X,d.T,d.subjects,d.durations,d.speeds
 folds=load_outer_folds(CODE/'protocol/outer_folds.csv',G)
 tasks=[(name,PRIMARY_TASKS[name]['sensors'],PRIMARY_TASKS[name]['targets'],PRIMARY_TASKS[name]['target_names']) for name in ['knee_two','ankle_two']]
else:
 d=np.load(ROOT/'physical'/'camargo_external.npz',allow_pickle=True)
 X,T,G,DUR,SPEED,folds=[d[k] for k in ('X','T','subjects','durations','speeds','outer_fold')]
 tasks=[('knee_two',(1,2),(0,1),('knee_stance_flex_deg','knee_swing_flex_deg')),('ankle_two',(2,3),(2,3),('ankle_dorsiflex_deg','ankle_plantarflex_deg'))]
tr=np.flatnonzero(folds!=fold);te=np.flatnonzero(folds==fold)
assert not(set(G[tr])&set(G[te]))
subj=G[te];rows=[];raw=[];start=time.time()
for ti,(name,sensors,targets,names) in enumerate(tasks):
 seed=(SEED+fold*2000000+int(round(CAP*10))*10000+ti if cohort=='virtual' else SEED+fold*100000+len(name)*1000+int(round(CAP*10)))
 xa,ya,ga,da,sa=make_augmented_training_set(X[tr],T[tr][:,targets],G[tr],DUR[tr],SPEED[tr],sensors,CAP,COPIES,seed)
 feature_train=engineered_features(xa,sensors,da,sa)
 model=WeightedRidge(100.).fit(feature_train,ya,np.full(len(feature_train),1./(COPIES+1)))
 Y=T[te][:,targets]
 base=model.predict(engineered_features(X[te],sensors,DUR[te],SPEED[te]))
 configs=[('clean','zero','none',None,None)]
 for ax in range(3):
  for sign in [1,-1]:
   r=axis_angle_to_matrix(np.eye(3)[ax],np.deg2rad(sign*ANG))
   rt=r.T
   for which in ['sensor_A','sensor_B','both_same','both_opposed']:
    configs.append(('rotated','xyz'[ax],('+' if sign==1 else '-')+str(ANG),which,(r,rt)))
 for condition,axis,angle,which,rot in configs:
  if condition=='clean':
   pe=base
  else:
   r,rt=rot;xe=X[te].copy()
   if which in ('sensor_A','both_same','both_opposed'):
    xe[:,sensors[0]]=rotate_sensor_block(X[te][:,sensors[0]],r)
   if which in ('sensor_B','both_same'):
    xe[:,sensors[1]]=rotate_sensor_block(X[te][:,sensors[1]],r)
   elif which=='both_opposed':
    xe[:,sensors[1]]=rotate_sensor_block(X[te][:,sensors[1]],rt)
   pe=model.predict(engineered_features(xe,sensors,DUR[te],SPEED[te]))
  for sid in np.unique(subj):
   ix=np.flatnonzero(subj==sid)
   for j,target in enumerate(names):
    e=pe[ix,j]-Y[ix,j];dp=pe[ix,j]-base[ix,j]
    rows.append(dict(cohort=cohort,outer_fold=fold,train_cap_deg=CAP,test_rotation_deg=0. if condition=='clean' else ANG,
     condition=condition,axis=axis,sign=angle,sensor_configuration=which or 'none',task=name,target=target,subject=int(sid),n_cycles=len(ix),
     participant_rmse_deg=float(np.sqrt(np.mean(e**2))),participant_mae_deg=float(np.mean(np.abs(e))),
     participant_max_abs_error_deg=float(np.max(np.abs(e))),participant_q95_abs_error_deg=float(np.quantile(np.abs(e),.95)),
     participant_prediction_shift_rms_deg=float(np.sqrt(np.mean(dp**2))),
     participant_fraction_cycles_abs_error_gt4p5=float(np.mean(np.abs(e)>4.5)),
     participant_baseline_rmse_deg=float(np.sqrt(np.mean((base[ix,j]-Y[ix,j])**2)))))
    if condition!='clean':
     for k in range(len(ix)):
      raw.append(dict(cohort=cohort,outer_fold=fold,condition=condition,axis=axis,sign=angle,sensor_configuration=which,task=name,target=target,
       subject=int(sid),cycle_index=int(te[ix[k]]),abs_error_deg=float(abs(e[k])),abs_prediction_shift_deg=float(abs(dp[k]))))
 print('DONE',cohort,fold,name,'seconds',round(time.time()-start,2),flush=True)
part=pd.DataFrame(rows);part.to_csv(out/f'axis_participant_{cohort}_fold{fold}.csv',index=False)
# Per-cycle details are present for independently checking quantile assertions.
pd.DataFrame(raw).to_csv(out/f'axis_cycle_{cohort}_fold{fold}.csv',index=False)
print('DONE_FOLD',cohort,fold,'participant_rows',len(part),'raw_rows',len(raw),'seconds',round(time.time()-start,2),flush=True)
