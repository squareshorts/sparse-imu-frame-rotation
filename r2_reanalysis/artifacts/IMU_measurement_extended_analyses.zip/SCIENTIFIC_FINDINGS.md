# Sensor-frame rotation: completed computational analyses

This report summarizes the model experiments underlying the revised article. It is a scientific-analysis record, not part of the anonymized paper.

## Input provenance

* Virtual: 747 cycles from 138 participants, SHA-256 `f75bc8ca9c9cad0a6d4b853b7fd55d3637e5a485dbfdb9f27fa18405cdd2db9e`.
* Physical: Camargo `Camargo_levelground.h5`, 248 windows from 19 participants, SHA-256 `c5faa8b545127176765b53f88d5551a10721beea760d3893f263a42154656b0a`.
* Original source: `squareshorts/sparse-imu-frame-rotation`, frozen commit `3609b490194670bf69f82c5a166ffdfa5aadb3f3`.
* Outer validation is participant-disjoint in both cohorts. All rotation models use the same defined feature extraction. Random-axis rotation uses 50 held-out realizations, and inference treats participant as the resampling unit (5,000 bootstrap draws).

## Physical-cohort nested Ridge selection

Regularization was selected on unrotated inner-validation data within each physical outer-training fold, over alpha in {0.01,0.1,1,10,100,1000,10000}. Alpha for the clean model was 100 in two folds and 1000 in three, versus the transferred alpha=10. Augmented (7.5- and 10-degree training caps) alpha=100 in all folds, identical to the transferred value. At 10-degree test rotation, nested tuning minus transferred-penalty mean participant RMSE was:

| Gait endpoint | Delta RMSE (degrees) | Paired 95% CI |
| --- | ---: | --- |
| Ankle dorsiflexion | -0.923 | [-1.498, -0.407] |
| Ankle plantarflexion | +0.190 | [-0.511, +1.001] |
| Knee stance flexion | -0.949 | [-1.651, -0.318] |
| Knee swing flexion | -1.738 | [-2.553, -0.985] |

The physical response to frame rotation remains much smaller after cohort-specific regularization. This does not establish which cohort-level input property causes the discrepancy.

## Prediction-response decomposition

Per participant, under a frame rotation, rotated squared error equals baseline squared error plus squared prediction shift plus twice the baseline-error/prediction-shift cross product. At 10-degree test rotations, the unaugmented mean within-participant RMS change in predictions was:

| Endpoint | Virtual (degrees) | Physical (degrees) | Virtual-physical difference, 95% CI |
| --- | ---: | ---: | --- |
| Ankle dorsiflexion | 8.058 | 1.754 | [6.083, 6.533] |
| Ankle plantarflexion | 8.095 | 2.058 | [5.803, 6.280] |
| Knee stance flexion | 7.984 | 2.519 | [5.188, 5.744] |
| Knee swing flexion | 7.915 | 2.753 | [4.815, 5.492] |

All virtual source-summary means were numerically reproduced to within 5.752e-9 degrees. The physical rotation-induced changes in predictions are smaller, not only the increments in RMSE relative to a high-error baseline. The decomposition does not identify a causal physical mechanism behind the between-cohort difference.

## Rotation-direction and tail-risk analysis

The 10-degree augmentation model was tested under 24 signed, exact 7.5-degree local-axis rotation conditions per endpoint: x/y/z axes, plus/minus sign, and rotation of the first sensor, second sensor, both in the same direction, or both in opposite directions. Thus 96 endpoint/axis/sensor configurations were evaluated in each cohort.

For virtual IMUs, 88 of 96 individual upper 95% bootstrap limits on participant-mean RMSE met the study-defined 4.5-degree threshold. All eight failures involved opposite-signed local-y rotations of the two sensors, in both directions, for each endpoint. The most adverse condition was knee stance flexion, with mean participant RMSE 5.711899 degrees, individual upper 95% interval endpoint 6.139797 degrees, participant RMSE 95th percentile 9.8101 degrees, and absolute cycle-error 95th percentile 10.5051 degrees.

Joint participant bootstrapping across all 96 conditions gave an estimated 95% interval of [5.621417, 6.157170] degrees for the maximum participant-mean RMSE. The earlier 13 of 13 random-axis 7.5-degree configurations passing the criterion describes the sampled random-axis distribution, **not an unconditional orientation tolerance**.

## Acceleration scaling

Uniformly multiplying physical acceleration inputs by 9.80665 and refitting the standardization and Ridge models in their respective physical training folds changed any individual prediction by at most 0.000154 degrees for the tested models and angles. This numerical unit-rescaling operation does not explain the cross-cohort sensitivity gap. It does not certify the original instrument calibration or physical units.

## Interpretation for Measurement

The strongest finding is the divergence between average random-axis performance and selected adverse relative-axis rotations. The other main result is that the prediction-sensitivity difference between virtual and physical representations persists after physical-specific Ridge regularization and uniform acceleration scaling. The participant bootstrap intervals describe precision of the specified participant-mean statistics; they do not constitute traceable instrument measurement uncertainty. No experiment physically removed and reattached IMUs, so real-world remounting tolerances are not identified.

## Limits

Analyses use the available two cohorts, four extrema, engineered Ridge features, and fixed perturbations; the participant cohorts are not exchangeable and their physical differences have not been causally isolated. The axis tests probe deterministic rotations, not the frequency of orientation errors in field placement. For the next physical-validation study, a preregistered actual-remounting protocol with measured axis-direction variability would be needed.
