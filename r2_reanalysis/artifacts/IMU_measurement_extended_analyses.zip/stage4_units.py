"""Source-unit conversion sensitivity of the fitted *physical* Ridge pipeline.

Test numerical invariance when every physical acceleration sample is multiplied by 9.80665,
with all transforms fit afresh on the converted training data within the same outer folds.
This is a numerical unit-convention check, not a claim that source unit metadata were verified.
"""
from __future__ import annotations
import sys,hashlib,json,time
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;CODE=ROOT/'repo'/'analysis_code';sys.path.insert(0,str(CODE))
from src.confirmatory.features import engineered_features
from src.confirmatory.orientation import make_augmented_training_set,perturb_by_subject
from strengthening.run_rotation_matrix_v2 import WeightedRidge
z=np.load(ROOT/'physical'/'camargo_external.npz',allow_pickle=True)
X,T,G,D,S,F=[z[k] for k in ('X','T','subjects','durations','speeds','outer_fold')]
X2=X.copy();X2[...,0:3]*=np.float32(9.80665)
tasks=[('knee_two',(1,2),(0,1)),('ankle_two',(2,3),(2,3))]
SEED=20260907;rows=[];start=time.time()
for fold in range(1,6):
 tr=np.flatnonzero(F!=fold);te=np.flatnonzero(F==fold);g=G[te]
 for name,sensors,targets in tasks:
  for cap in (0.,10.):
   wt=None;models=[]
   for XX in (X,X2):
    seed=SEED+fold*100000+len(name)*1000+int(round(cap*10))
    copies=5 if cap>0 else 0
    xa,ya,ga,da,sa=make_augmented_training_set(XX[tr],T[tr][:,targets],G[tr],D[tr],S[tr],sensors,cap,copies,seed)
    w=np.full(len(xa),1./(copies+1)) if copies else np.ones(len(xa))
    models.append(WeightedRidge(10. if cap==0 else 100.).fit(engineered_features(xa,sensors,da,sa),ya,w))
   for ang in (0.,10.):
    for rep in range(1 if ang==0 else 50):
     seed=SEED+fold*1000000+len(name)*10000+int(round(ang*10))*100+rep
     xx,_=perturb_by_subject(X[te],g,sensors,ang,seed,exact_angle=True) if ang else (X[te],None)
     x2,_=perturb_by_subject(X2[te],g,sensors,ang,seed,exact_angle=True) if ang else (X2[te],None)
     p1=models[0].predict(engineered_features(xx,sensors,D[te],S[te]))
     p2=models[1].predict(engineered_features(x2,sensors,D[te],S[te]))
     err=np.abs(p1-p2)
     rows.append(dict(fold=fold,task=name,train_cap_deg=cap,test_angle_deg=ang,rep=rep,
       max_abs_prediction_deviation_deg=float(err.max()),mean_abs_prediction_deviation_deg=float(err.mean()),
       mean_sq_prediction_deviation_deg2=float(np.mean((p1-p2)**2))))
  print('DONE',fold,name,'elapsed',round(time.time()-start,1),flush=True)
out=ROOT/'results'/'units';out.mkdir(parents=True,exist_ok=True)
df=pd.DataFrame(rows);df.to_csv(out/'physical_unit_conversion_repetitions.csv',index=False)
sumdf=df.groupby(['task','train_cap_deg','test_angle_deg'],as_index=False).agg(n_evaluations=('rep','size'),max_prediction_deviation_deg=('max_abs_prediction_deviation_deg','max'),mean_absolute_prediction_deviation_deg=('mean_abs_prediction_deviation_deg','mean'))
sumdf.to_csv(out/'physical_unit_conversion_summary.csv',index=False)
print('MAX ABS deviation',df.max_abs_prediction_deviation_deg.max());print(sumdf.to_string(index=False))
