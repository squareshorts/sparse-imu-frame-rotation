from __future__ import annotations
import hashlib
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'/'axis_stress'
P=pd.concat([pd.read_csv(OUT/f'axis_participant_{co}_fold{i}.csv') for co in ['virtual','physical'] for i in range(1,6)],ignore_index=True)
C=pd.concat([pd.read_csv(OUT/f'axis_cycle_{co}_fold{i}.csv') for co in ['virtual','physical'] for i in range(1,6)],ignore_index=True)
C['sign']=C['sign'].astype(float).map(lambda x: f'{x:+g}')
P.to_csv(OUT/'all_axis_participants.csv',index=False)
C.to_csv(OUT/'all_axis_cycles.csv',index=False)
for co,n in [('virtual',138),('physical',19)]:
 q=P[P.cohort==co]
 assert len(q[q.condition=='clean'])==n*4
 assert len(q[q.condition=='rotated'])==n*4*24
 assert q.groupby(['subject','target']).outer_fold.nunique().eq(1).all()
 assert q.groupby(['subject','target','axis','sign','sensor_configuration'],dropna=False).size().eq(1).all()

def boot_mean(a,seed,B=5000):
 a=np.asarray(a,float);r=np.random.default_rng(seed)
 bs=np.mean(a[r.integers(0,len(a),size=(B,len(a)))],axis=1)
 return (float(a.mean()),*map(float,np.quantile(bs,[.025,.975])))
rows=[]
GROUP=['cohort','condition','axis','sign','sensor_configuration','target']
raw_group={k:q for k,q in C.groupby(['cohort','condition','axis','sign','sensor_configuration','target'],dropna=False,sort=False)}
for key,q in P.groupby(GROUP,dropna=False,sort=True):
 co,condition,axis,sign,which,tgt=key
 kk=str(key).encode();seed=int.from_bytes(hashlib.sha256(kk).digest()[:4],'little')
 m,lo,hi=boot_mean(q.participant_rmse_deg,seed)
 row=dict(zip(GROUP,key));row.update(n_subjects=len(q),n_cycles=int(q.n_cycles.sum()),
  mean_participant_rmse_deg=m,mean_rmse_ci95_low_deg=lo,mean_rmse_ci95_high_deg=hi,
  participant_rmse_p95_deg=float(np.quantile(q.participant_rmse_deg,.95)),
  participant_rmse_max_deg=float(q.participant_rmse_deg.max()),
  proportion_participants_rmse_gt4p5=float(np.mean(q.participant_rmse_deg>4.5)),
  mean_participant_prediction_shift_rms_deg=float(q.participant_prediction_shift_rms_deg.mean()),
  mean_participant_q95_abs_error_deg=float(q.participant_q95_abs_error_deg.mean()),
  participant_mean_fraction_cycles_abs_error_gt4p5=float(q.participant_fraction_cycles_abs_error_gt4p5.mean()),
  pass_mean_upper_ci_le_4p5=bool(hi<=4.5) if co=='virtual' else None)
 if condition=='rotated':
  raw=raw_group[key]
  row['all_cycles_q95_abs_error_deg']=float(raw.abs_error_deg.quantile(.95))
  row['all_cycles_q99_abs_error_deg']=float(raw.abs_error_deg.quantile(.99))
  row['all_cycles_q95_abs_prediction_shift_deg']=float(raw.abs_prediction_shift_deg.quantile(.95))
 rows.append(row)
S=pd.DataFrame(rows);S.to_csv(OUT/'axis_endpoint_summary.csv',index=False)
source_base=S[S.condition=='clean'].copy();diffs=[]
for co,source in [('virtual',ROOT/'repo'/'source_data'/'virtual_rotation_matrix_summary.csv'),('physical',ROOT/'repo'/'source_data'/'external_rotation_matrix_summary.csv')]:
 ref=pd.read_csv(source)
 rf=ref[(ref.train_augmentation_max_deg==10)&(ref.test_rotation_deg==0)]
 merged=source_base[source_base.cohort==co][['target','mean_participant_rmse_deg']].merge(rf[['target','mean_participant_rmse_deg']],on='target',suffixes=('_new','_source'),validate='one_to_one')
 maxdiff=float((merged.mean_participant_rmse_deg_new-merged.mean_participant_rmse_deg_source).abs().max())
 diffs.append([co,maxdiff]);assert maxdiff<5e-4,(co,maxdiff)
A=S[S.condition=='rotated'].copy()
B=A.groupby(['cohort','target'],as_index=False).agg(worst_upper_ci=('mean_rmse_ci95_high_deg','max'),worst_mean_rmse=('mean_participant_rmse_deg','max'),
   worst_participant_p95=('participant_rmse_p95_deg','max'),maximum_q95_cycle_error=('all_cycles_q95_abs_error_deg','max'),
   axis_configurations=('pass_mean_upper_ci_le_4p5','size'),axis_configurations_passing_4p5=('pass_mean_upper_ci_le_4p5',lambda x:sum(v is True for v in x)))
B['failures']=B.axis_configurations-B.axis_configurations_passing_4p5
B.to_csv(OUT/'axis_risk_by_endpoint.csv',index=False)
Ccount=A.groupby(['cohort','sensor_configuration'],as_index=False).agg(configurations=('pass_mean_upper_ci_le_4p5','size'),passing=('pass_mean_upper_ci_le_4p5',lambda x:sum(v is True for v in x)),worst_upper_ci=('mean_rmse_ci95_high_deg','max'),worst_q95_cycle_error=('all_cycles_q95_abs_error_deg','max'))
Ccount.to_csv(OUT/'axis_risk_by_sensor_configuration.csv',index=False)
A.sort_values(['cohort','mean_rmse_ci95_high_deg'],ascending=[True,False]).groupby('cohort').head(20).to_csv(OUT/'worst_axis_conditions.csv',index=False)
print('Source clean cap10 matches',diffs)
print('Endpoints\n',B.to_string(index=False));print('Sensor config\n',Ccount.to_string(index=False))
print('Worst virtual\n',A[A.cohort=='virtual'].sort_values('mean_rmse_ci95_high_deg',ascending=False).head(10)[GROUP+['mean_participant_rmse_deg','mean_rmse_ci95_high_deg','participant_rmse_p95_deg','all_cycles_q95_abs_error_deg']].to_string(index=False))
