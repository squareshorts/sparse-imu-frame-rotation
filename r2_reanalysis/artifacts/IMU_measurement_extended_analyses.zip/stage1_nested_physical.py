"""Nested participant-disjoint physical-cohort Ridge tuning; exact original feature/augmentation machinery.

Use python 3.13 with numpy 2.3, pandas 2.2, scipy 1.17, sklearn 1.8.
"""
from __future__ import annotations
import sys,json,time,hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
ROOT=Path(__file__).resolve().parent
REPO=ROOT/'repo'/'analysis_code';sys.path.insert(0,str(REPO))
from src.confirmatory.orientation import make_augmented_training_set,perturb_by_subject
from src.confirmatory.features import engineered_features
from strengthening.run_rotation_matrix_v2 import WeightedRidge
from src.confirmatory.metrics import composite_participant_rmse
D=np.load(ROOT/'physical'/'camargo_external.npz',allow_pickle=True)
OUT=ROOT/'results'/'physical_nested';OUT.mkdir(parents=True,exist_ok=True)
X,T,G,F,DUR,SPEED=[D[k] for k in ('X','T','subjects','outer_fold','durations','speeds')]
TASKS=[('knee_two',(1,2),(0,1),('knee_stance_flex_deg','knee_swing_flex_deg')),('ankle_two',(2,3),(2,3),('ankle_dorsiflex_deg','ankle_plantarflex_deg'))]
ALPHAS=[0.01,.1,1.,10.,100.,1000.,10000.]
CAPS=[0.,7.5,10.];ANGLES=[0.,7.5,10.];MC=50;COPIES=5;SEED=20260907

def augment_rows(idx,sensors,targets,cap,seed):
 copies=COPIES if cap>0 else 0
 xt,yt,gt,dt,st=make_augmented_training_set(X[idx],T[idx][:,targets],G[idx],DUR[idx],SPEED[idx],sensors,cap,copies,seed)
 ft=engineered_features(xt,sensors,dt,st)
 weight=np.full(len(ft),1./(copies+1)) if copies else np.ones(len(ft))
 return ft,yt,weight

def boot_ci(a,seed=1,B=5000):
 a=np.asarray(a,float);rng=np.random.default_rng(seed)
 b=np.mean(a[rng.integers(0,len(a),(B,len(a)))],axis=1)
 return [float(a.mean()),*map(float,np.quantile(b,[.025,.975]))]

start=time.time(); cvrows=[]; models={}; picks=[]
for fold in range(1,6):
 tr=np.flatnonzero(F!=fold);te=np.flatnonzero(F==fold)
 assert not (set(G[tr])&set(G[te]))
 cv=list(GroupKFold(3).split(np.zeros(len(tr)),groups=G[tr]))
 for cap in CAPS:
  foldscores={a:[] for a in ALPHAS}
  for infold,(ii,iv) in enumerate(cv,1):
   itrain=tr[ii]; ival=tr[iv];s=[]
   for taskname,sensors,targets,endpoints in TASKS:
    seed=SEED+91000000+fold*2000000+int(round(cap*10))*10000+infold*100+len(taskname)
    ftr,ytr,w=augment_rows(itrain,sensors,targets,cap,seed)
    fva=engineered_features(X[ival],sensors,DUR[ival],SPEED[ival])
    for alpha in ALPHAS:
     m=WeightedRidge(alpha).fit(ftr,ytr,w)
     score=composite_participant_rmse(T[ival][:,targets],m.predict(fva),G[ival]); s.append({'alpha':alpha,'score':score,'task':taskname})
   for alpha in ALPHAS:
    mean=float(np.mean([x['score'] for x in s if x['alpha']==alpha]));foldscores[alpha].append(mean)
    cvrows.append({'outer_fold':fold,'train_cap_deg':cap,'inner_fold':infold,'alpha':alpha,'participant_mean_rmse_deg':mean})
  means={alpha:float(np.mean(scores)) for alpha,scores in foldscores.items()};best=min(ALPHAS,key=lambda a:(means[a],a))
  picks.append({'outer_fold':fold,'train_cap_deg':cap,'selected_alpha':best,**{f'mean_cv_{a:g}':means[a] for a in ALPHAS}})
  for taskname,sensors,targets,endpoints in TASKS:
   final_seed=SEED+fold*100000+len(taskname)*1000+int(round(cap*10))
   ftr,ytr,w=augment_rows(tr,sensors,targets,cap,final_seed)
   for label,alpha in [('fixed_source',10. if cap<=2.5 else 100.),('nested_cv',best)]:
    models[(fold,taskname,cap,label)]=WeightedRidge(alpha).fit(ftr,ytr,w)
  print('tuned',fold,cap,'selected',best,'scores',round(means[best],4),'seconds',round(time.time()-start,1),flush=True)

pd.DataFrame(cvrows).to_csv(OUT/'inner_cv_scores.csv',index=False)
pd.DataFrame(picks).to_csv(OUT/'alpha_selection.csv',index=False)

acc=defaultdict(lambda:[0.,0,0.,0.,0]) # se2_rot se2_base shift2 cross n
errors=defaultdict(list);predshifts=defaultdict(list)
for fold in range(1,6):
 te=np.flatnonzero(F==fold);g=G[te];uniq=np.unique(g)
 smap={s:np.flatnonzero(g==s) for s in uniq}
 for taskname,sensors,targets,endpoints in TASKS:
  y=T[te][:,targets]
  p0={}
  for cap in CAPS:
   for label in ['fixed_source','nested_cv']:
    p0[(cap,label)]=models[(fold,taskname,cap,label)].predict(engineered_features(X[te],sensors,DUR[te],SPEED[te]))
  for ang in ANGLES:
   reps=1 if ang==0 else MC
   for rep in range(reps):
    if ang==0:xe=X[te]
    else:
     testseed=SEED+fold*1000000+len(taskname)*10000+int(round(ang*10))*100+rep
     xe,_=perturb_by_subject(X[te],g,sensors,ang,testseed,exact_angle=True)
    fte=engineered_features(xe,sensors,DUR[te],SPEED[te])
    for cap in CAPS:
     for label in ['fixed_source','nested_cv']:
      p=models[(fold,taskname,cap,label)].predict(fte)
      base=p0[(cap,label)]
      err0=base-y;delta=p-base;e=p-y
      for s,ix in smap.items():
       for j,target in enumerate(endpoints):
        k=(label,cap,ang,taskname,target,int(s));a=acc[k]
        a[0]+=float(np.sum(e[ix,j]**2));a[1]+=float(np.sum(err0[ix,j]**2));a[2]+=float(np.sum(delta[ix,j]**2));a[3]+=float(np.sum(2*err0[ix,j]*delta[ix,j]));a[4]+=len(ix)
        errors[k].extend(np.abs(e[ix,j]).tolist());predshifts[k].extend(np.abs(delta[ix,j]).tolist())
   print('test',fold,taskname,ang,'elapsed',round(time.time()-start,1),flush=True)

rows=[]
for k,a in acc.items():
 label,cap,ang,taskname,target,sid=k;se,base,shift,cross,n=a
 assert n>0 and abs(se-(base+shift+cross))<max(1e-3,1e-6*se),(k,se,base+shift+cross)
 rows.append(dict(variant=label,train_cap_deg=cap,test_angle_deg=ang,task=taskname,target=target,subject=sid,
                  pooled_error_count=n,rmse_deg=float(np.sqrt(se/n)),baseline_mse_deg2=base/n,
                  delta_pred_mse_deg2=shift/n,cross_mse_deg2=cross/n,rotated_mse_deg2=se/n,
                  q95_absolute_error_deg=float(np.percentile(errors[k],95)),
                  q95_absolute_prediction_shift_deg=float(np.percentile(predshifts[k],95))))
part=pd.DataFrame(rows);part.to_csv(OUT/'participant_nested_and_decomp.csv',index=False)
summary=[]
for i,(keys,dd) in enumerate(part.groupby(['variant','train_cap_deg','test_angle_deg','target'],sort=True)):
 var,cap,ang,tgt=keys
 rm=boot_ci(dd.rmse_deg,1000+i)
 base=boot_ci(np.sqrt(dd.baseline_mse_deg2),2000+i)
 delta=boot_ci(np.sqrt(dd.delta_pred_mse_deg2),3000+i)
 q95=boot_ci(dd.q95_absolute_error_deg,4000+i)
 summary.append(dict(variant=var,train_cap_deg=cap,test_angle_deg=ang,target=tgt,n_subjects=len(dd),
                     mean_rmse_deg=rm[0],ci95_low_deg=rm[1],ci95_high_deg=rm[2],
                     mean_clean_rmse_deg=base[0],mean_prediction_shift_rms_deg=delta[0],
                     mean_baseline_mse_deg2=float(dd.baseline_mse_deg2.mean()),
                     mean_delta_pred_mse_deg2=float(dd.delta_pred_mse_deg2.mean()),
                     mean_cross_mse_deg2=float(dd.cross_mse_deg2.mean()),
                     mean_rotated_mse_deg2=float(dd.rotated_mse_deg2.mean()),
                     mean_subject_q95_abs_error_deg=q95[0]))
sumdf=pd.DataFrame(summary);sumdf.to_csv(OUT/'nested_summary.csv',index=False)
paired=[]
for i,(k,q) in enumerate(part.groupby(['train_cap_deg','test_angle_deg','target'])):
 cap,ang,tgt=k
 ref=q[q.variant=='fixed_source'][['subject','rmse_deg']].rename(columns={'rmse_deg':'fixed'})
 tun=q[q.variant=='nested_cv'][['subject','rmse_deg']].rename(columns={'rmse_deg':'nested'})
 mm=ref.merge(tun,on='subject',validate='one_to_one')
 mean,lo,hi=boot_ci(mm.nested-mm.fixed,5000+i)
 paired.append(dict(train_cap_deg=cap,test_angle_deg=ang,target=tgt,n_subjects=len(mm),
                    delta_nested_minus_fixed_mean_rmse_deg=mean,ci95_low_deg=lo,ci95_high_deg=hi))
pd.DataFrame(paired).to_csv(OUT/'nested_vs_fixed_paired.csv',index=False)
print('finished_seconds',round(time.time()-start,1),'summary\n',sumdf[sumdf.test_angle_deg.eq(10)].to_string(index=False),flush=True)
