from pathlib import Path
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
figout=R/'measurement_revision'/'fig6_prediction_shift_directional.pdf'
figout.parent.mkdir(parents=True, exist_ok=True)
V=pd.read_csv(R/'results/virtual_decomp/participant_prediction_decomposition.csv')
P=pd.read_csv(R/'results/physical_nested/participant_nested_and_decomp.csv')
P=P[P.variant.eq('fixed_source')]
A=pd.read_csv(R/'results/axis_stress/axis_endpoint_summary.csv')
vs=pd.read_csv(R/'results/virtual_decomp/decomposition_summary.csv')
end=['ankle_dorsiflex_deg','ankle_plantarflex_deg','knee_stance_flex_deg','knee_swing_flex_deg']
lab=['Ankle DF','Ankle PF','Knee stance','Knee swing']

def bci(x,seed):
 x=np.asarray(x,float);r=np.random.default_rng(seed);b=np.mean(x[r.integers(0,len(x),(5000,len(x)))],axis=1)
 return float(x.mean()),list(map(float,np.quantile(b,[.025,.975])))
fig,axes=plt.subplots(2,1,figsize=(7.2,7.7))
ax=axes[0]
for shift,(name,d) in zip([-.12,.12],[('Virtual IMU',V),('Physical IMU',P)]):
 means=[]; lows=[]; highs=[]
 for i,t in enumerate(end):
  q=d[(d.train_cap_deg==0)&(d.test_angle_deg==10)&(d.target==t)]
  m,(lo,hi)=bci(np.sqrt(q.delta_pred_mse_deg2),500+i+(0 if shift<0 else 30))
  means.append(m);lows.append(m-lo);highs.append(hi-m)
 ax.errorbar(np.arange(4)+shift,means,yerr=[lows,highs],fmt='o' if shift<0 else 's',capsize=3,linewidth=1.4,markersize=5,label=name)
ax.set_title('(a) Prediction sensitivity at 10°',loc='left',fontsize=11)
ax.set_ylabel('RMS change in predicted angle (deg)')
ax.set_xticks(range(4),lab,rotation=22,ha='right',fontsize=9)
ax.set_ylim(bottom=0);ax.legend(frameon=False,fontsize=9,loc='upper right')
ax.grid(axis='y',alpha=.2)
ax=axes[1];ax.axhline(4.5,color='gray',ls='--',lw=1.2,label='4.5° criterion')
sets=[('Random axes, 50 draws',-.17,'o'),('Opposing y, +7.5°',0.,'^'),('Opposing y, -7.5°',.17,'s')]
for k,(name,dx,mark) in enumerate(sets):
 means=[];low=[];up=[]
 for t in end:
  if k==0:
   v=vs[(vs.train_cap_deg==10)&(vs.test_angle_deg==7.5)&(vs.target==t)].iloc[0]
   m,l,h=v.mean_rmse_deg,v.ci95_low_deg,v.ci95_high_deg
  else:
   v=A[(A.cohort=='virtual')&(A.target==t)&(A.condition=='rotated')&(A.axis=='y')&(A.sign==('+' if k==1 else '-')+'7.5')&(A.sensor_configuration=='both_opposed')].iloc[0]
   m,l,h=v.mean_participant_rmse_deg,v.mean_rmse_ci95_low_deg,v.mean_rmse_ci95_high_deg
  means.append(m);low.append(m-l);up.append(h-m)
 ax.errorbar(np.arange(4)+dx,means,yerr=[low,up],fmt=mark,capsize=3,linewidth=1.3,markersize=5,label=name)
ax.set_title('(b) Virtual IMU with 10° training augmentation',loc='left',fontsize=11)
ax.set_ylabel('Mean participant RMSE (deg)')
ax.set_xticks(range(4),lab,rotation=22,ha='right',fontsize=9)
ax.set_ylim(2,6.65);ax.grid(axis='y',alpha=.2)
ax.legend(frameon=False,fontsize=8,loc='upper left',ncol=2)
fig.subplots_adjust(left=.15,right=.97,hspace=.67,top=.94,bottom=.12)
fig.savefig(figout,metadata={'Title':'Rotation-induced prediction shifts and signed-axis errors','Creator':'Python matplotlib numerical plot'})
fig.savefig(figout.with_suffix('.png'),dpi=220)
plt.close(fig)
print('FIG',figout,figout.stat().st_size)
